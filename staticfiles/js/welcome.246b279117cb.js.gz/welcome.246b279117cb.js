setTimeout(function() {

    var input = document.getElementById("pitch-url-input");
    input.addEventListener("click", function() {
        this.select();
    });

}, 1000);
